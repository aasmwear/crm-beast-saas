declare module 'ziggy' {
  import type { Plugin } from 'vue'
  export const ZiggyVue: Plugin
}
