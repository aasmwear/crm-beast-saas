<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @method static \Illuminate\Database\Eloquent\Builder<self> query()
 */
class Task extends Model
{
    protected $guarded = [];

    protected $casts = [
        'assignees' => 'array',
        'due_date' => 'datetime',
    ];

    /** @return BelongsTo<\App\Models\Project, self> */
    public function project(): BelongsTo
    {
        return $this->belongsTo(Project::class);
    }

    /** @return BelongsTo<\App\Models\Organization, self> */
    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }
}
