<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @use \Illuminate\Database\Eloquent\Factories\HasFactory<\Database\Factories\ClientFactory>
 * @method static \Database\Factories\ClientFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder<self> query()
 *
 * @property int $id
 * @property int $organization_id
 * @property string $company_name
 * @property int|null $assigned_account_manager_id
 * @property-read \App\Models\Organization $organization
 */
class Client extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'organization_id',
        'company_name',
        'industry',
        'niche',
        'primary_contact_name',
        'primary_contact_email',
        'primary_contact_phone',
        'website',
        'address',
        'tags',
        'fronter',
        'closer',
        'assigned_account_manager_id',
        'google_business_profile_status',
        'google_business_profile_access_status',
        'client_activation_status',
        'notes_by_cst',
        'notes_by_sales',
        'notes_by_tech',
        'status',
        'search_vector',
    ];

    protected $casts = [
        'tags' => 'array',
        'fronter' => 'array',
        'closer' => 'array',
    ];

    /** @return BelongsTo<\App\Models\Organization, self> */
    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    /** @return HasMany<\App\Models\Project, self> */
    public function projects(): HasMany
    {
        return $this->hasMany(Project::class);
    }

    /** @return BelongsTo<\App\Models\User, self> */
    public function assignedAccountManager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_account_manager_id');
    }

    /**
     * Back-compat alias so older code that calls $client->accountManager still works.
     *
     * @return BelongsTo<\App\Models\User, self>
     */
    public function accountManager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_account_manager_id');
    }

    public function getAccountManagerIdAttribute(): ?int
    {
        return $this->assigned_account_manager_id;
    }

    public function setAccountManagerIdAttribute(?int $value): void
    {
        $this->attributes['assigned_account_manager_id'] = $value;
    }

    /**
     * @param  Builder<self>  $q
     * @return Builder<self>
     */
    public function scopeForOrg(Builder $q, Organization|int $org): Builder
    {
        $orgId = $org instanceof Organization ? $org->id : $org;

        return $q->where('organization_id', $orgId);
    }

    /**
     * Visible if:
     *  - Admin/manager in the org, or
     *  - Assigned account manager, or
     *  - Fronter/closer, or
     *  - Has tasks on any project for this client.
     *
     * @param  Builder<self>  $q
     * @return Builder<self>
     */
    public function scopeVisibleTo(Builder $q, User $user, Organization $org): Builder
    {
        if ($user->hasRole(['Admin', 'HR', 'DepartmentHead'], $org)) {
            return $q->forOrg($org);
        }

        return $q->forOrg($org)->where(function ($qq) use ($user) {
            $qq->where('assigned_account_manager_id', $user->id)
                ->orWhereJsonContains('fronter', $user->id)
                ->orWhereJsonContains('closer', $user->id)
                ->orWhereExists(function ($sub) use ($user) {
                    $sub->from('projects')
                        ->join('tasks', 'tasks.project_id', '=', 'projects.id')
                        ->whereColumn('projects.client_id', 'clients.id')
                        ->whereJsonContains('tasks.assignees', (string) $user->id);
                });
        });
    }

    /**
     * @param  Builder<self>  $q
     * @return Builder<self>
     */
    public function scopeSearch(Builder $q, ?string $term): Builder
    {
        if (! $term) {
            return $q;
        }

        $like = '%'.strtolower($term).'%';

        return $q->where(function ($qq) use ($like) {
            $qq->whereRaw('LOWER(company_name) LIKE ?', [$like])
                ->orWhereRaw('LOWER(industry) LIKE ?', [$like])
                ->orWhereRaw('LOWER(primary_contact_email) LIKE ?', [$like])
                ->orWhereRaw('LOWER(primary_contact_phone) LIKE ?', [$like]);
        });
    }
}
