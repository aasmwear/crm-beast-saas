<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;

/**
 * @use \Illuminate\Database\Eloquent\Factories\HasFactory<\Database\Factories\UserFactory>
 * @method static \Database\Factories\UserFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder<self> query()
 *
 * @property int $id
 * @property int|null $department_id
 *
 * @method static static create(array<string, mixed> $attributes = [])
 */
class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, HasFactory, HasRoles, Notifiable;

    /**
     * Spatie Permission guard.
     */
    protected string $guard_name = 'web';

    /**
     * Mass assignable attributes.
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'department_id',
    ];

    /**
     * Hidden attributes for arrays.
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Attribute casting.
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /** @return BelongsToMany<\App\Models\Organization, self, \Illuminate\Database\Eloquent\Relations\Pivot, 'pivot'> */
    public function organizations(): BelongsToMany
    {
        // Pivot: organization_user (organization_id, user_id)
        return $this->belongsToMany(Organization::class, 'organization_user')->withTimestamps();
    }

    /** @return BelongsTo<\App\Models\Department, self> */
    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }

    /** @return HasMany<\App\Models\Project, self> */
    public function projects(): HasMany
    {
        return $this->hasMany(Project::class, 'project_manager_id');
    }
}
