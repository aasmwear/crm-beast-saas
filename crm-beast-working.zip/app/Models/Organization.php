<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @use \Illuminate\Database\Eloquent\Factories\HasFactory<\Database\Factories\OrganizationFactory>
 * @method static \Database\Factories\OrganizationFactory factory($count = null, $state = [])
 * @method static \Illuminate\Database\Eloquent\Builder<self> query()
 *
 * @property int $id
 * @property string $name
 * @property string $slug
 * @property string|null $plan
 * @property array<string, mixed> $settings
 */
class Organization extends Model
{
    use HasFactory;

    protected $guarded = [];

    /** @return HasMany<\App\Models\Client, self> */
    public function clients(): HasMany
    {
        return $this->hasMany(Client::class);
    }

    /** @return HasMany<\App\Models\Project, self> */
    public function projects(): HasMany
    {
        return $this->hasMany(Project::class);
    }

    /** @return BelongsToMany<\App\Models\User, self, \Illuminate\Database\Eloquent\Relations\Pivot, 'pivot'> */
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class)->withTimestamps();
    }
}
