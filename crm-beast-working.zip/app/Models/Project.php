<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * @method static \Illuminate\Database\Eloquent\Builder<self> query()
 */
class Project extends Model
{
    protected $guarded = [];

    /** @return BelongsTo<\App\Models\Client, self> */
    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    /** @return BelongsTo<\App\Models\Organization, self> */
    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    /** @return HasMany<\App\Models\Task, self> */
    public function tasks(): HasMany
    {
        return $this->hasMany(Task::class);
    }
}
